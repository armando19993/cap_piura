<?php

namespace App\Http\Controllers;

use App\Models\UsuariosExterno;
use Illuminate\Http\Request;
Use Carbon\Carbon;

class UsuariosExternoController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $fecha = substr($request->fecha_nacimiento, 0, 10);
        $usuario = new UsuariosExterno();
        $usuario->nombres = $request->nombres;
        $usuario->apellido_parteno = $request->apellido_paterno;
        $usuario->apellido_materno = $request->apellido_materno;
        $usuario->dni = $request->dni;
        $usuario->fecha_nacimiento = $fecha;
        $usuario->sexo = $request->sexo;
        $usuario->correo = $request->correo;
        $usuario->ruc = $request->ruc;
        $usuario->celular = $request->celular;
        $usuario->direccion = $request->direccion;
        $usuario->grado = $request->grado;
        $usuario->profesion = $request->profesion;
        $usuario->estado = 1;
        $usuario->clave = sha1($request->dni);
        $usuario->save();

        return $usuario->id;
    }


    public function show(Request $request)
    {
        $usuario = UsuariosExterno::where('dni', $request->dni)->where('clave', sha1($request->clave))->first();

        return $usuario;
    }

    public function edit(UsuariosExterno $usuariosExterno)
    {
        //
    }

    public function update(Request $request, UsuariosExterno $usuariosExterno)
    {
        //
    }

    public function destroy(UsuariosExterno $usuariosExterno)
    {
        //
    }
}
